class HaloLightRifle : HaloDoomBaseWeapon
{
	bool isAiming;
	uint charge;
	const LR_FULLCHARGE = 40; //how long it takes for the rifle to charge in ADS mode (in tics)
	int flashSpark;

	Default
	{
		Tag "Light rifle";
		// These ammo definitions are for testing purposes.
		// Please replace with your mag/reserve system
		// as needed when implementing:
		+Weapon.AMMO_OPTIONAL
		Weapon.AmmoType1 "HDLightRifleMag";
		Weapon.AmmoGive1 0;
		Weapon.AmmoUse1 1;
		Weapon.AmmoType2 "Clip";
		Weapon.AmmoGive2 108;
		Weapon.AmmoUse2 0;
		Weapon.SlotNumber 4;
	}

	/*override void DoEffect()
	{
		if (owner && owner.player && owner.player.cmd.buttons & BT_ATTACK)
		{
			Console.MidPrint(smallfont, String.Format("Charge: \cd%d\c-", charge));
		}
	}*/

	action void A_LRReady(int flags = WRF_ALLOWRELOAD)
	{
		// Makes sure the playe has to press Altfire again
		// to toggle ADS, so that it doesn't keep toggling
		// back and forth if the player holds altfire:
		if (player.oldbuttons & BT_ALTATTACK)
		{
			flags |= WRF_NOSECONDARY;
		}
		A_MagazineWeaponReady(flags);
	}

	// Does a single reload "pump":
	action state A_ReloadPump()
	{
		int magAmt, magMax, resAmt;
		[magAmt, magMax, resAmt] = invoker.CheckMagWeaponAmmo();
		// Try to load 3 per pump, but no more than we have
		// in reserves and no mor than can fit in the mag:
		int amtToLoad = min(3, resAmt, magMax - magAmt);
		// Reload calculated amount:
		invoker.ammo1.amount += amtToLoad;
		A_TakeInventory(invoker.ammotype2, amtToLoad, TIF_NOTAKEINFINITE);
		// Done?
		[magAmt, magMax, resAmt] = invoker.CheckMagWeaponAmmo();
		if (magAmt >= magMax || resAmt < invoker.ammouse1)
		{
			// Done reloading (full mag or no reserves), stop here:
			A_StartAnimationLayer("Anim_ChargeEnd");
			return ResolveState("ReloadEnd");
		}
		// Not done:
		return ResolveState(null);
	}

	action void A_LRBurstFire()
	{
		if (!invoker.CheckMagWeaponAmmo()) return;
		A_HDGunFlash();
		A_HDMuzzleHighlightgs();
		A_FireBullets(2, 2, 1, 8);
	}

	action void A_LRADSFire()
	{
		if (!invoker.DepleteAmmo(false, true, 6, true))
		{
			return;
		}
		A_HDGunFlash(flash:"FlashADS");
		A_HDMuzzleHighlightgs(flash:"HighlightsADS");
		A_FireBullets(2, 2, 1, 30, flags:0);
	}

	// Make sure one full magazine is given the first time
	// this weapon is attached to the player:
	override void AttachToOwner(Actor other)
	{
		Super.AttachToOwner(other);
		if (owner)
		{
			let def = GetDefaultByType(ammotype1);
			if (def)
			{
				owner.A_SetInventory(ammotype1, def.maxamount);
			}
		}
	}

	override State GetReadyState ()
	{
		if (isAiming)
		{
			return FindState('ReadyADS');
		}
		return Super.GetReadyState();
	}

	override State GetAtkState (bool hold)
	{
		if (isAiming)
		{
			return FindState('FireADS');
		}
		return Super.GetAtkState(hold);
	}

	States {
	Select:
		TNT1 A 0 
		{
			// always disable ADS on selection if for some
			// reason it was on and the weapon got removed:
			invoker.isAiming = false;
			A_StartAnimationLayer("Anim_Select");
		}
		#### ###### 1 A_WeaponReady(WRF_NOFIRE|WRF_NOBOB);
		goto Ready;
	FirstSelect:
		TNT1 A 0 A_StartAnimationLayer("Anim_FirstSelect");
		#### # 1 A_WeaponReady(WRF_NOFIRE|WRF_NOBOB);
		wait; //this is ended from Anim_ChargeEnd
	Deselect:
		TNT1 A 6 
		{
			// Disable ADS on deselection:
			invoker.isAiming = false;
			invoker.charge = 0;
			A_StartAnimationLayer("Anim_Deselect");
		}
		#### # 0 A_WeaponOffset(0, WEAPONBOTTOM);
		#### # 0 A_Lower;
		wait;
	Ready:
		TNT1 A 0
		{
			invoker.charge = 0;
			invoker.isAiming = false;
		}
		HLR1 A 1 A_LRReady();
		loop;
	Fire:
		TNT1 A 0 
		{
			if (!invoker.CheckMagWeaponAmmo())
			{
				return ResolveState("Reload");
			}
			A_StartAnimationLayer("Anim_Fire");
			return ResolveState(null);
		}
		TNT1 AAA 2 A_LRBurstFire();
		HLR1 A 6;
		HLR1 A 1 A_ReFire;
		goto Ready;
	Flash:
		HLRF A 1 bright
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale.x = psp.scale.y = frandom[flash](0.8, 1.0);
				psp.rotation = frandom[flash](-30, 30);
				psp.frame = random[flash](0,2);
			}
		}
		#### # 1 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale *= 0.5;
			}
		}
		stop;
	Highlights:
		HLRF Z 1 bright A_AnimateHighlights();
		HLRF ZZ 1 bright 
		{
			A_AnimateHighlights();
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha *= 0.5;
			}
		}
		stop;
	Reload:
		TNT1 A 0
		{
			if (!invoker.isAiming)
			{
				return ResolveState("ReloadCheck");
			}
			return ResolveState(null);
		}
		// Show ADS off animation before reloading
		// if we were aiming:
		HLR4 ABCD 1;
		goto ReloadCheck;
	ReloadCheck:
		TNT1 A 0 
		{
			invoker.charge = 0;
			if (!invoker.CanMagazineReload())
			{
				invoker.isAiming = false;
				return ResolveState("Ready");
			}
			return ResolveState("ReloadStart");
		}
	ReloadStart:
		TNT1 A 9 
		{
			A_ClearRefire();
			A_StartAnimationLayer("Anim_Reload");
		}
	ReloadLoop:
		TNT1 A 5 A_StartAnimationLayer("Anim_PumpLoop");
		TNT1 A 0 A_ReloadPump();
		TNT1 A 12;
		loop;
	ReloadEnd:
		// Wait for charge animation to finish
		// (see "Anim_ChargeEnd"):
		TNT1 A -1;
		stop;
	AltFire:
		TNT1 A 0 
		{
			A_ClearAnimationLayer();
			if (invoker.isAiming)
			{
				invoker.isAiming = false;
				return ResolveState("ADSOff");
			}
			invoker.isAiming = true;
			return ResolveState(null);
		}
	ADSOn:
		HLR4 DCB 1;
		goto ReadyADS;
	ADSOff:
		TNT1 A 0 { invoker.charge = 0; }
		HLR4 ABCD 1;
		goto Ready;
	ReadyADS:
		TNT1 A 0 A_ClearAnimationLayer();
		HLR4 A 1 
		{
			A_LRReady();
			if (invoker.charge > 0)
			{
				invoker.charge--;
			}
		}
		wait;
	FireADS:
		TNT1 A 0 
		{
			if (invoker.CheckMagWeaponAmmo() < 6)
			{
				
				return ResolveState("Reload");
			}
			A_HDGunFlash(PSP_HDFLASH, flash:"ChargeOrb");
			return ResolveState(null);
		}
		HLR4 A 1
		{
			A_OverlayPivot(OverlayID(), 0.5, 0.5);
			A_OverlayScale(OverlayID(), 1, 1, WOF_INTERPOLATE);
			invoker.charge++;
			A_Overlay(PSP_GUNLIGHTS, "FireADSChargeLights", true);
			if (invoker.charge >= LR_FULLCHARGE)
			{
				invoker.charge = 0;
				return ResolveState("FireAdsEnd");
			}
			if (!(player.cmd.buttons & BT_ATTACK))
			{
				return ResolveState("ReadyADS");
			}
			return ResolveState(null);
		}
		wait;
	// Charge finished - fire:
	FireADSEnd:
		TNT1 A 0 A_LRADSFire();
		HLR5 CD 1
		{
			A_OverlayScale(OverlayID(), 0.15, 0.15, WOF_ADD);
		}
		HLR5 DDCCBBAA 1
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale.x = psp.scale.y = Clamp(psp.scale.x - 0.03, 1, psp.scale.x);
			}
		}
		HLR4 A 10
		{
			A_OverlayScale(OverlayID(), 1, 1);
			A_Overlay(PSP_GUNLIGHTS, "FireADSChargeLightsFadeout");
		}
		goto ReadyADS;
	// Orb below the barrel while charging, drawn on muzzle flash layer:
	ChargeOrb:
		HLO1 ABCDEFGHIJKLMNOPQRSTUVWXYZ 1 bright
		{
			if (!invoker.isAiming)
			{
				return ResolveState("Null");
			}
			if (!IsLayerInsequence(PSP_WEAPON, "FireADS"))
			{
				A_PSPFadeOut(OverlayID(), 0.2, 0.2);
			}
			return ResolveState(null);
		}
		HLO2 ABCDEFGHIJKLMNOPQRSTUVWXYZ 1 bright
		{
			if (!invoker.isAiming)
			{
				return ResolveState("Null");
			}
			if (!IsLayerInsequence(PSP_WEAPON, "FireADS"))
			{
				A_PSPFadeOut(OverlayID(), 0.2, 0.2);
			}
			return ResolveState(null);
		}
		stop;
	// Overlay with red lights, drawn on top of main layer while charging
	// (on the PSP_GUNLIGHTS layer, separate from muzzle highlights):
	FireADSChargeLights:
		TNT1 A 0
		{
			A_OverlayFlags(OverlayID(), PSPF_RenderStyle|PSPF_ForceAlpha, true);
			A_OverlayRenderStyle(OverlayID(), Style_Translucent);
		}
		HLR5 A 1
		{
			if (!invoker.isAiming || invoker.charge <= 0)
			{
				return ResolveState("Null");
			}
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha = invoker.charge / double(LR_FULLCHARGE);
				if (psp.alpha <= 0)
				{
					return ResolveState("Null");
				}
			}
			return ResolveState(null);
		}
		wait;
	// Overlay with red lights fading out after firing in ADS mode:
	FireADSChargeLightsFadeout:
		HLR5 A 1 
		{
			A_OverlayFlags(OverlayID(), PSPF_RenderStyle|PSPF_ForceAlpha, true);
			A_OverlayRenderStyle(OverlayID(), Style_Translucent);
		}
		HLR5 AAAAAAAAA 1
		{
			if (!invoker.isAiming)
			{
				return ResolveState("Null");
			}
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha -= 0.22;
			}
			return ResolveState(null);
		}
		stop;
	// Muzzle flash when firing in ADS mode:
	FlashADS:
		HLRG A 1 bright
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.frame = random[flash](0,2);
				psp.rotation = frandom[flash](-30, 30);
			}
		}
		#### # 1 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale *= 0.5;
			}
		}
		stop;
	// Muzzle highlights when firing in ADS mode:
	HighlightsAds:
		HLRG Z 1 bright A_AnimateHighlights();
		HLRG ZZ 1 bright 
		{
			A_AnimateHighlights();
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha *= 0.5;
			}
		}
		stop;

	Anim_Ready:
		HLR1 A -1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
		stop;
	Anim_Fire:
		HLR2 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-4.63, 0.80), (1.05, 1.05), -2.38);
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.74, 0.13), (1.00, 1.00), -0.38);
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-4.63, 0.80), (1.05, 1.05), -2.38);
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (-2.51, 0.43), (1.03, 1.03), -1.29);
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-7.15, 1.24), (1.08, 1.08), -3.67);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-7.11, 1.23), (1.08, 1.08), -3.66);
		#### C 1 A_UpdateAnimationLayer(PSP_WEAPON, (-6.88, 1.19), (1.08, 1.08), -3.54);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-6.25, 1.08), (1.07, 1.07), -3.21);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-5.03, 0.87), (1.06, 1.06), -2.58);
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (-3.01, 0.52), (1.03, 1.03), -1.54);
		#### A 1 
		{
			A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
			A_OverlayFlags(OverlayID(), PSPF_RenderStyle|PSPF_ForceAlpha, true);
			A_OverlayRenderStyle(OverlayID(), Style_Translucent);
		}
		#### ##### 1
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha -= 0.25;
			}
		}
		stop;
	Anim_Select:
		HLR1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (101.47, -111.13), (0.86, 0.86), 23.60);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (96.88, -99.66), (0.88, 0.88), 21.45);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (84.95, -72.30), (0.92, 0.92), 16.26);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (68.45, -39.61), (0.96, 0.96), 9.93);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (50.13, -12.12), (1.00, 1.00), 4.33);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (32.76, -0.41), (1.02, 1.02), 1.36);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (18.65, -0.17), (1.02, 1.02), 0.57);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (8.38, -0.05), (1.02, 1.02), 0.17);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.12, -0.00), (1.01, 1.01), 0.02);
		goto Anim_Ready;
	Anim_Deselect:
		HLR1 # 1 A_UpdateAnimationLayer(PSP_WEAPON, (8.38, -0.05), (1.02, 1.02), 0.17, (1, 1));
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (32.76, -0.41), (1.02, 1.02), 1.36, (1, 1));
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (50.13, -12.12), (1.00, 1.00), 4.33, (1, 1));
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (68.45, -39.61), (0.96, 0.96), 9.93, (1, 1));
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (96.88, -99.66), (0.88, 0.88), 21.45, (1, 1));
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (101.47, -125), (0.86, 0.86), 23.60, (1, 1));
		stop;
	Anim_FirstSelect:
		HLR3 E 1 A_UpdateAnimationLayer(PSP_WEAPON, (37.73, -145.97), (0.84, 0.84), 26.87);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (35.60, -136.45), (0.85, 0.85), 25.37);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (30.22, -112.49), (0.87, 0.87), 21.54);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (23.12, -81.05), (0.90, 0.90), 16.38);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (15.80, -49.06), (0.92, 0.92), 10.92);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (9.80, -23.46), (0.95, 0.95), 6.15);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (6.63, -11.19), (0.97, 0.97), 3.08);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.71, -8.35), (0.98, 0.98), 1.47);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.29, -6.32), (0.98, 0.98), 0.32);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.18, -4.95), (0.98, 0.98), -0.43);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.17, -4.12), (0.99, 0.99), -0.89);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.06, -3.70), (0.99, 0.99), -1.13);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (4.65, -3.54), (0.99, 0.99), -1.23);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.73, -3.52), (0.99, 0.99), -1.28);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.67, -3.83), (1.00, 1.00), -1.34);
		HLR3 F 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.84, -4.41), (1.00, 1.00), -1.40);
		HLR3 G 1 A_UpdateAnimationLayer(PSP_WEAPON, (-2.06, -4.72), (1.00, 1.00), -1.42);
	Anim_ChargeEnd:
		HLR3 G 1 A_UpdateAnimationLayer(PSP_WEAPON, (-2.06, -4.71), (1.00, 1.00), -1.42);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-2.01, -4.68), (1.00, 1.00), -1.40);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-1.89, -4.58), (1.00, 1.00), -1.35);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-1.64, -4.39), (1.00, 1.00), -1.26);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-1.24, -4.08), (1.00, 1.00), -1.11);
		HLR3 H 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.64, -3.61), (1.00, 1.00), -0.88);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.19, -2.96), (1.00, 1.00), -0.55);
		#### I 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.30, -2.09), (1.00, 1.00), -0.13);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.82, 0.10), (1.00, 1.00), 0.45);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.75, 0.10), (1.00, 1.00), 0.44);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.54, 0.09), (1.00, 1.00), 0.43);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.21, 0.09), (1.00, 1.00), 0.40);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (4.80, 0.08), (1.00, 1.00), 0.37);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (4.31, 0.07), (1.00, 1.00), 0.33);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.77, 0.06), (1.00, 1.00), 0.29);
		#### J 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.20, 0.05), (1.00, 1.00), 0.24);
		#### K 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.62, 0.04), (1.00, 1.00), 0.20);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.05, 0.03), (1.00, 1.00), 0.16);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.51, 0.02), (1.00, 1.00), 0.11);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.02, 0.01), (1.00, 1.00), 0.07);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.60, 0.01), (1.00, 1.00), 0.04);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.28, 0.00), (1.00, 1.00), 0.02);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.07, 0.00), (1.00, 1.00), 0.00);
		#### L 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
		#### M 1 A_UpdateAnimationLayer(PSP_WEAPON, (14.92, 4.56), (1.04, 1.04), 0.0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (11.46, 4.54), (1.04, 1.04), -0.39);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.20, 4.39), (1.03, 1.03), -1.34);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-6.65, 4.00), (1.02, 1.02), -2.47);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-14.92, 3.24), (1.02, 1.02), -3.42);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-18.38, 1.99), (1.00, 1.00), -3.82);
		#### A 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-3.73, 0.41), (1.0, 1.0), -0.56);
		HLR1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (-7.46, 0.83), (1.0, 1.0), -1.13);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-3.73, 0.41), (1.0, 1.0), -0.56);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.00), (1.0, 1.0), 0.0);
		TNT1 A 0 
		{
			let psp = player.FindPSprite(PSP_WEAPON);
			if (psp && !InStateSequence(psp.curstate, invoker.GetReadyState()))
			{
				if (invoker.isAiming)
				{
					psp.SetState(ResolveState("ADSOn"));
				}
				else
				{
					psp.SetState(invoker.GetReadyState());
				}
			}
		}
		goto Anim_Ready;
	Anim_Reload:
		HLR3 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.10, -0.04), (0.99, 0.99), -0.02);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.38, -0.17), (0.99, 0.99), -0.10);
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.80, -0.39), (0.99, 0.99), -0.21);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.31, -0.68), (0.99, 0.99), -0.35);
		#### C 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.86, -1.03), (0.99, 0.99), -0.52);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.41, -1.44), (0.99, 0.99), -0.69);
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.92, -1.90), (0.99, 0.99), -0.86);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.34, -2.41), (0.99, 0.99), -1.02);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.62, -2.95), (0.99, 0.99), -1.17);
		wait;
	Anim_PumpLoop:
		#### E 1 A_UpdateAnimationLayer(PSP_WEAPON, (3.73, -3.52), (0.99, 0.99), -1.28);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.67, -3.83), (1.00, 1.00), -1.34);
		#### F 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.84, -4.41), (1.00, 1.00), -1.40);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-2.06, -4.72), (1.00, 1.00), -1.42);
		#### G 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.84, -4.41), (1.00, 1.00), -1.40);
		#### # 2 A_UpdateAnimationLayer(PSP_WEAPON, (1.67, -3.83), (1.00, 1.00), -1.34);
		#### # 2 A_UpdateAnimationLayer(PSP_WEAPON, (-0.84, -4.41), (1.00, 1.00), -1.40);
		#### F 2 A_UpdateAnimationLayer(PSP_WEAPON, (-2.06, -4.72), (1.00, 1.00), -1.42);
		#### # 2 A_UpdateAnimationLayer(PSP_WEAPON, (-0.84, -4.41), (1.00, 1.00), -1.40);
		#### # 2 A_UpdateAnimationLayer(PSP_WEAPON, (1.67, -3.83), (1.00, 1.00), -1.34);
		#### E 2 A_UpdateAnimationLayer(PSP_WEAPON, (3.73, -3.52), (0.99, 0.99), -1.28);
		wait;
	}
}

// Standard "magazine" ammo code.
// Replace with your own as needed.
class HDLightRifleMag : Ammo
{
	Default
	{
		+Inventory.IGNORESKILL
		Inventory.MaxAmount 36;
		Ammo.BackPackAmount 0;
		Ammo.BackPackMaxAmount 36;
	}
}