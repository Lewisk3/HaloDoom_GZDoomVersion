class HaloPistol : HaloDoomBaseWeapon
{
	uint charge;
	const MAXCHARGE = 80;
	int flashSpark;

	Default
	{
		Tag "Pistol";
		Weapon.AmmoType1 'Clip';
		Weapon.AmmoGive1 40;
		Weapon.AmmoUse1 1;
		Weapon.SlotNumber 2;
	}

	action void A_FireHaloPistol()
	{
		A_HDGunFlash();
		A_HDMuzzleHighlightgs();
		A_FireBullets(4, 2, 1, 8 + invoker.charge);
		invoker.charge = 0;
	}

	action void A_FireOverchargedPistol()
	{
		A_FireBullets(4, 2, 1, 12 + invoker.charge);
	}

	States {
	Select:
		TNT1 A 0 A_StartAnimationLayer("Anim_Select");
		HPI0 AAAAAA 1 A_WeaponReady(WRF_NOFIRE|WRF_NOBOB);
		goto Ready;
	FirstSelect:
		TNT1 A 0 A_StartAnimationLayer("Anim_FirstSelect");
		HPI0 A 3;
		HPI0 B 4;
		HPI0 C 5;
		HPI0 B 7;
		HPI1 A 7;
		goto Ready;

	Deselect:
		HPI1 A 6 A_StartAnimationLayer("Anim_Deselect");
		TNT1 A 0 A_WeaponOffset(0, WEAPONBOTTOM);
		TNT1 A 0 A_Lower;
		wait;
	Ready:
		HPI1 A 1 A_WeaponReady();
		wait;
	Fire:
		TNT1 A 0 A_StartAnimationLayer("Anim_Fire");
		HPI1 A 7 A_FireHaloPistol();
		HPI1 A 3 A_ReFire;
		goto Ready;
	Highlights:
		HPI1 Y 1 bright A_AnimateHighlights();
		HPI1 YY 1 bright 
		{
			A_AnimateHighlights();
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.alpha *= 0.5;
			}
		}
		stop;
	Flash:
		HPI1 Z 1 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale.x = psp.scale.y = frandom[flash](0.4, 0.55);
			}
		}
		HPI1 Z 1 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale *= 0.6;
			}
		}
		stop;
	AltFire:
		HPI2 AB 3;
		#### # 2
		{
			if (invoker.charge > MAXCHARGE)
			{
				return ResolveState("Overcharge");
			}
			if (!(player.cmd.buttons & BT_ALTATTACK))
			{
				return ResolveState("Fire");
			}
			invoker.charge += 1;

			A_HDGunFlash(flash:"ChargeFlash", (-15,0));
			if (frandom[ovrc](0, 0.5) <= (invoker.charge / double(MAXCHARGE)))
			{
				A_HDGunFlash(PSP_HDFLASH + 1 + invoker.flashSpark, flash:"ChargeLightning", (-15,0));
				invoker.flashSpark++;
				if (invoker.flashSpark > 5)
				{
					invoker.flashSpark = 0;
				}
			}
			
			A_WeaponOffset(randompick[ovrc](-1,1) * (invoker.charge / double(MAXCHARGE)), 
				WEAPONTOP + randompick[ovrc](-1,1) * (invoker.charge / double(MAXCHARGE)), 
				WOF_INTERPOLATE);
			A_OverlayRotate(OverlayID(), 1 * (invoker.charge / double(MAXCHARGE)) * randompick[ovrc](-1,1), WOF_INTERPOLATE);
			return ResolveState(null);
		}
		wait;
	ChargeFlash:
		HPI1 Z 3 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			if (psp)
			{
				psp.scale.x = psp.scale.y = 0.7 + frandom[flash](0.1, 0.4) * (invoker.charge / double(MAXCHARGE));
				double basealpha = 0.7 * (Clamp(invoker.charge, 0, 10) / 10.0);
				psp.alpha = basealpha + frandom[flash](0, 0.3);
			}
		}
		stop;
	ChargeLightning:
		HPIF # 1 bright 
		{
			let psp = player.FindPSprite(OverlayID());
			psp.frame = random[ovrc](0,3);
			psp.rotation = frandom[ovrc](0, 360);
			double sc = 0.5 + 0.5 * (invoker.charge / double(MAXCHARGE));
			psp.scale = (sc * randompick[ovrc](-1, 1), sc * randompick[ovrc](-1, 1));
		}
		#### ### 1 bright
		{
			let psp = player.FindPSprite(OverlayID());
			psp.alpha *= 0.7;
		}
		stop;
	Overcharge:
		TNT1 A 0 
		{
			A_StartAnimationLayer("Anim_Overcharge");
			A_FireOverchargedPistol();
		}
		HPI2 CDE 1;
		HPI2 F 1
		{
			A_Overlay(PSP_HDHIGHLIGHTS, "OverchargeLight");
			if (invoker.charge <= 0)
			{
				return ResolveState("OverchargeEnd");
			}
			invoker.charge--;
			return ResolveState(null);
		}
		wait;
	OverchargeLight:
		HPIF E 1 bright
		{
			int layer = OverlayID();
			A_OverlayFlags(layer, PSPF_RenderStyle|PSPF_ForceAlpha, true);
			A_OverlayRenderStyle(layer, STYLE_Add);
			let psp = player.FindPSprite(layer);
			let main = player.FindPSprite(PSP_WEAPON);
			if (psp && main)
			{
				psp.pivot = main.pivot;
				psp.bPivotPercent = main.bPivotPercent;
				psp.rotation = main.rotation;
				psp.bInterpolate = main.bInterpolate;
				psp.scale = main.scale;
				psp.alpha = 2 * (invoker.charge / double(MAXCHARGE));
			}
		}
		stop;
	OverchargeEnd:
		TNT1 A 0 A_StartAnimationLayer("Anim_OverchargeReturn");
		HPI2 GHIJA 2;
		goto Ready;
	
	/*Anim_Idle:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON);
		loop;*/

	Anim_Select:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 71.09, -88.74 ),	( 0.89, 0.89 ), 31.89 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 64.35, -76.03 ),	( 0.89, 0.89 ), 26.46 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 48.44, -47.78 ),	( 0.9, 0.9 ), 14.53 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 29.75, -18.80 ),	( 0.92, 0.92 ), 2.6 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 14.73, -3.90 ),	( 0.94, 0.94 ), -2.81 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 6.21, -1.65 ),	( 0.96, 0.96 ), -2.37 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 1.83, -0.49 ),	( 0.98, 0.98 ), -1.4 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 0.23, -0.06 ),	( 0.99, 0.99 ), -0.44 );
		stop;
	
	Anim_FirstSelect:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (46.96, -87.90), (0.89, 0.89), 31.89);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (46.68, -81.97), (0.90, 0.90), 29.95);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (46.00, -67.16), (0.94, 0.94), 25.12);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (45.12, -47.90), (0.99, 0.99), 18.84);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (44.23, -28.64), (1.04, 1.04), 12.56);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (43.55, -13.83), (1.08, 1.08), 7.72);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (43.28, -7.90), (1.10, 1.10), 5.79);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (45.26, -13.46), (1.08, 1.08), 7.24);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (49.00, -24.20), (1.03, 1.03), 10.03);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.19, -31.21), (1.00, 1.00), 11.81);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.43, -32.89), (0.98, 0.98), 12.18);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.55, -33.76), (0.97, 0.97), 12.38);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.60, -34.08), (0.97, 0.97), 12.45);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.60, -34.12), (0.97, 0.97), 12.46);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.58, -33.73), (0.97, 0.97), 12.30);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.39, -32.57), (0.97, 0.97), 11.86);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (50.87, -30.72), (0.98, 0.98), 11.15);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (49.87, -28.23), (0.98, 0.98), 10.21);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (48.22, -25.17), (0.99, 0.99), 9.06);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (45.76, -21.60), (0.99, 0.99), 7.74);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (42.32, -17.57), (0.99, 0.99), 6.26);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (37.75, -13.15), (1.00, 1.00), 4.66);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (28.92, -8.50), (1.00, 1.00), 3.00);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (16.27, -4.27), (1.00, 1.00), 1.50);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON, (4.92, -1.19), (1.00, 1.00), 0.41);
		stop;

 
	Anim_Deselect:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 1.83, -0.49 ),	( 0.98, 0.98 ), -1.4 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 6.21, -1.65 ),	( 0.96, 0.96 ), -2.37 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 14.73, -3.90 ),	( 0.94, 0.94 ), -2.81 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 29.75, -18.80 ),	( 0.92, 0.92 ), 2.6 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 48.44, -47.78 ),	( 0.9, 0.9 ), 14.53 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 71.09, -88.74 ),	( 0.89, 0.89 ), 31.89 );
		stop;

	Anim_Fire:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON);
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -7.52, -5.93 ),	( 1.05, 1.05 ), -3.13 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -15.03, -11.85 ),	( 1.1, 1.1 ), -6.26 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -9.69, -3.61 ),	( 1.04, 1.04 ), -2.39 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -2.89, -4.62 ),	( 0.99, 0.99 ), 1.47 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -0.86, -3.92 ),	( 0.99, 0.99 ), 1.24 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -0.11, -2.20 ),	( 0.99, 0.99 ), 0.68 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON);
		stop;

	Anim_Overcharge:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -1.89, 2.19 ),	( 1.01, 1.01 ), -0.64 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -6.87, 4.24 ),	( 1.03, 1.04 ), -1.22 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -13.90, 6.10 ),	( 1.05, 1.07 ), -1.71 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -21.97, 7.74 ),	( 1.07, 1.1 ), -2.12 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -30.04, 9.09 ),	( 1.1, 1.13 ), -2.45 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -37.07, 10.11 ),	( 1.12, 1.16 ), -2.68 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -42.05, 10.76 ),	( 1.13, 1.18 ), -2.83 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -43.94, 10.98 ),	( 1.13, 1.19 ), -2.88 );
		TNT1 A 3 A_UpdateAnimationLayer(PSP_WEAPON,	( -43.94 + frandom[ovrc](-1,1), 10.98  + frandom[ovrc](-1,1)),	( 1.13, 1.19 ), -2.88  + frandom[ovrc](-0.35, 0.35) );
		wait;

	Anim_OverchargeReturn:
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -38.49, 8.93 ),	( 1.12, 1.16 ), -1.75 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -26.03, 4.62 ),	( 1.08, 1.1 ), 0.35 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -12.43, 0.87 ),	( 1.04, 1.04 ), 1.48 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( -2.48, -0.92 ),	( 1.02, 1.01 ), 0.79 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 3.18, -1.58 ),	( 1, 1 ), -0.47 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 4.97, -1.68 ),	( 1, 1 ), -1.16 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 2.48, -0.84 ),	( 1, 1 ), -0.58 );
		TNT1 A 1 A_UpdateAnimationLayer(PSP_WEAPON);
		stop;
	}
}
