class HaloDoomBaseWeapon : Weapon
{
	const PSP_ANIMATIONLAYER = 5000; //layer for animation controller (may or may not show sprites)
	const PSP_HDFLASH = -1000; //muzzle flash below the weapon
	const PSP_GUNLIGHTS = 5500; //extra lights that might be needed on the gun
	const PSP_HDHIGHLIGHTS = 6000; //muzzle highlights (above animation layer in case anim layer draws sprites)
	bool firstSelectDone;

	Default
	{
		Weapon.WeaponScaleY 1.0;
	}

	// Handle first selection animation.
	// Add CVar checks etc. as necessary:
	override State GetUpState ()
	{
		if (firstSelectDone)
		{
			return Super.GetUpState();
		}
		firstSelectDone = true;
		let st = FindState("FirstSelect");
		return st? st : Super.GetUpState();
	}

	action void A_StartAnimationLayer(StateLabel sequence)
	{
		let animState = ResolveState(sequence);
		if (!animState) return;
		
		player.SetPSprite(PSP_ANIMATIONLAYER, animState);
	}

	action void A_UpdateAnimationLayer(int layer, Vector2 p_ofs = (0,0), Vector2 p_scale = (1, 1), double rotation = 0, Vector2 pivot = (0.5, 0.5))
	{
		let psp = player.FindPSprite(layer);
		if (!psp) return;

		psp.bPivotPercent = true;
		psp.pivot = pivot;
		p_ofs *= -1.0;
		
		if (layer == PSP_WEAPON || !psp.bAddWeapon)
		{
			p_ofs.y += WEAPONTOP;
		}
		psp.bInterpolate = false; //important
		psp.x = p_ofs.x;
		psp.y = p_ofs.y;
		psp.scale = p_scale;
		psp.rotation = rotation;
		//Console.Printf("Layer \cy%d\c- pos: current \cd%.1f,%.1f\c- target \cd%.1f,%.1f\c- ", layer, psp.x, psp.y, p_ofs.x, p_ofs.y);

		// Copy transforms to the animation layer:
		// this is done in case the animation layer
		// shows some sprites by itself.
		let psa = player.FindPSprite(PSP_ANIMATIONLAYER);
		if (psa)
		{
			psa.bPivotPercent = psp.bPivotPercent;
			psa.pivot = psp.pivot;
			psa.scale = psp.scale;
			psa.rotation = psp.rotation;
		}
	}

	action void A_ClearAnimationLayer()
	{
		let psp = player.FindPSprite(PSP_ANIMATIONLAYER);
		if (psp)
		{
			psp.SetState(ResolveState("Null"));
		}
	}

	// Wrapper for A_WeaponReady to be used with
	// magazine-fed weapons
	action void A_MagazineWeaponReady(int flags = WRF_ALLOWRELOAD)
	{
		// cannot reload (mag full or not enough reserves):
		if (!invoker.CanMagazineReload())
		{
			flags &= ~WRF_ALLOWRELOAD;
		}
		A_WeaponReady(flags);
	}

	bool CanMagazineReload()
	{
		int magAmt, magMax, resAmt;
		[magAmt, magMax, resAmt] = CheckMagWeaponAmmo();
		return (magAmt < magMax && resAmt >= ammouse1);
	}

	// Returns current mag ammo, max mag size, and current reserv ammo
	// for magazine-fed weapons.
	// If the final mod uses a different system,
	// amend this function's contents as necessary:
	int, int, int CheckMagWeaponAmmo()
	{
		if (!ammo1 || !ammo2) return -1, -1, -1;
		return ammo1.amount, ammo1.maxamount, ammo2.amount;
	}

	// Draws a muzzle flash below the gun and performs the necessary setup:
	action void A_HDGunFlash(int layer = PSP_HDFLASH, StateLabel flash = "Flash", Vector2 ofs = (0,0))
	{
		State flashstate = ResolveState(flash);
		if (!flashstate) return;
		let psp = player.GetPSprite(layer);
		psp.SetState(flashstate);
		psp.x = ofs.x;
		psp.y = ofs.y;
		psp.bPivotPercent = true;
		psp.pivot = (0.5, 0.5);
		A_OverlayFlags(layer, PSPF_RenderStyle|PSPF_ForceAlpha, true);
		A_OverlayRenderStyle(layer, STYLE_Add);
	}

	// Draws muzzle highlights on top of the gun:
	action void A_HDMuzzleHighlightgs(StateLabel flash = "Highlights", Vector2 ofs = (0,0))
	{
		A_HDGunFlash(PSP_HDHIGHLIGHTS, flash, ofs);
	}

	action void A_PSPFadeOut(int layer, double alphafactor = 0, double scalefactor = 0)
	{
		let psp = player.FindPSprite(layer);
		if (!psp) return;
		psp.alpha -= alphafactor;
		psp.scale.x -= scalefactor;
		psp.scale.y -= scalefactor;
		if (psp.alpha <= 0 || min(psp.scale.x, psp.scale.y) <= 0)
		{
			psp.SetState(ResolveState("Null"));
		}
	}

	action bool IsLayerInsequence(int layer, StateLabel label)
	{
		let psp = player.FindPSprite(layer);
		if (!psp) return false;
		State st = ResolveState(label);
		if (!st) return false;
		return InStateSequence(psp.curstate, st);
	}

	// This is to be continuously called on the 
	// muzzle highlights layer, to make it follow
	// the main layer:
	action void A_AnimateHighlights(int fromLayer = PSP_WEAPON)
	{
		let main = player.FindPSprite(fromLayer);
		let psp = player.FindPSprite(OverlayID());
		if (main && psp)
		{
			psp.bPivotPercent = main.bPivotPercent;
			psp.pivot = main.pivot;
			psp.scale = main.scale;
			psp.rotation = main.rotation;
		}
	}
}