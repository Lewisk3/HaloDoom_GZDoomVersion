class HaloEnergySword : HaloDoomBaseWeapon
{
	// left arm layer (just above animation layer)
	const PSP_LEFTARM = PSP_ANIMATIONLAYER + 1;
	// every main attack will hide left hand for this many tics:
	const LEFTARMWAIT = 40;
	// these are offsets towards which the left hand will be
	// moved when the right arm is attacking:
	const LEFTARMMOVEOFS_X = 65;
	// WEAPONTOP must be added because left hand layer sets
	// bAddWeapon to false:
	const LEFTARMMOVEOFS_Y = 100 + WEAPONTOP;

	// this is flipped on every melee attach to switch
	// between horizontal and overhead slashes:
	bool attackswitch;
	// delay before the left arm starts returning to its
	// base position:
	uint leftArmHideTimer;

	Default
	{
		Tag "Energy Sword";
		Weapon.SlotNumber 1;
	}

	// Super simple wrapper that prevents melee attacks
	// by holding buttons:
	action void A_SwordReady(int flags = 0)
	{
		if (player.oldbuttons & BT_ALTATTACK)
			flags |= WRF_NOSECONDARY;
		if (player.oldbuttons & BT_ATTACK)
			flags |= WRF_NOPRIMARY;
		A_WeaponReady(flags);
	}

	// An extremely simple refire that activates by
	// tapping the attack button again, but not by
	// holding it down:
	action State A_SimpleMeleeRefire()
	{
		int btn;
		State st;
		if (invoker.bAltFire)
		{
			btn = BT_ALTATTACK;
			st = ResolveState("AltFire");
		}
		else
		{
			btn = BT_ATTACK;
			st = ResolveState("Fire");
		}
		if ((player.cmd.buttons & btn) && !(player.oldbuttons & btn))
		{
			return st;
		}
		return ResolveState(null);
	}

	override void DoEffect()
	{
		Super.DoEffect();
		if (!owner || !owner.player || !owner.player.readyweapon || owner.player.readyweapon != self)
		{
			return;
		}

		// Makes sure the left arm layer exists:
		let player = owner.player;
		let psp = player.FindPSprite(PSP_LEFTARM);
		if (!psp)
		{
			// if it doesn't exist, set it up and initally place it
			// in a "hidden" position:
			psp = player.GetPSprite(PSP_LEFTARM);
			psp.SetState(FindState("Anim_LeftArmReady"));
			psp.bAddWeapon = false; //important
			psp.x = -LEFTARMMOVEOFS_X;
			psp.y = LEFTARMMOVEOFS_Y;
		}
	}

	States {
	Select:
		TNT1 A 0 A_StartAnimationLayer("Anim_Select");
		TNT1 A 6 A_WeaponReady(WRF_NOFIRE|WRF_NOBOB);
		goto Ready;
	FirstSelect:
		TNT1 A 47 A_StartAnimationLayer("Anim_FirstSelect");
		goto Ready;

	Ready:
		TNT1 A 1 A_SwordReady;
		loop;
	Fire:
		TNT1 A 0 
		{
			invoker.leftArmHideTimer = LEFTARMWAIT; // this makes the left arm hide
			if (invoker.attackswitch)
				A_StartAnimationLayer("Anim_Overhead");
			else
				A_StartAnimationLayer("Anim_Fire");
			
			invoker.attackswitch = !invoker.attackswitch;
		}
		#### # 16; //put your attack here
		#### ########## 1 A_SimpleMeleeRefire;
		goto Ready;
	AltFire:
		TNT1 A 4 
		{
			invoker.leftArmHideTimer = LEFTARMWAIT; // this makes the left arm hide
			A_StartAnimationLayer("Anim_Charge");
		}
		// this frame is looped as long as the player
		// is holding the altfire button:
		#### # 1
		{
			if (!(player.cmd.buttons & BT_ALTATTACK))
			{
				return ResolveState("AltFireDo");
			}
			invoker.leftArmHideTimer = LEFTARMWAIT;  // this keeps left arm hidden while holding attack
			return ResolveState(null);
		}
		wait;
	// this is the release of the altfire
	AltFireDo:
		TNT1 A 0 A_StartAnimationLayer("Anim_ChargeEnd");
		TNT1 A 0 A_Recoil(-30); //just for demo purposes; replace with some proper movement function and attack
		#### # 12;
		#### #### 1 A_SimpleMeleeRefire;
		goto Ready;
	Deselect:
		TNT1 A 6 A_StartAnimationLayer("Anim_Deselect");
		#### A 0 A_WeaponOffset(0, WEAPONBOTTOM);
		#### A 0 A_Lower;
		wait;
	
	// Left arm layer:
	Anim_LeftArmReady:
		HESW Z 1 
		{
			let psp = player.FindPSprite(OverlayID());
			if (!psp) return ResolveState("Null");
			
			// only allow this layer to bob while it's fully selected:
			psp.bAddBob = invoker.leftArmHideTimer? false : true;
			// decide into which direction the arm must move based on
			// the leftArmhideTimer value:
			double dir = invoker.leftArmHideTimer? 15 : -8;
			// move the arm (it moves slightly less horizontally because
			// the horizontal offset is a bit smaller than vertical):
			psp.x = clamp(psp.x - dir*0.8, -LEFTARMMOVEOFS_X, 0);
			psp.y = clamp(psp.y + dir, WEAPONTOP, LEFTARMMOVEOFS_Y);
			// when the left arm is fully pushed left and down, start counting
			// down the wait timer (once it reaches zero, the code above
			// will take care of moving the hand back):
			if (psp.x <= -LEFTARMMOVEOFS_X && psp.y >= LEFTARMMOVEOFS_Y)
			{
				if (invoker.leftArmHideTimer)
				{
					invoker.leftArmHideTimer--;
				}
			}
			return ResolveState(null);
		}
		loop;

	Anim_Ready:
		HESW D -1 A_UpdateAnimationLayer(PSP_WEAPON, (0.0, 0.0), (1.0, 1.0), 0.0);
		stop;

	Anim_Select:
		#### # 0 { invoker.leftArmHideTimer = 0; } //trigger select of left arm
		HESW D 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 71.09, -88.74 ),	( 0.89, 0.89 ), 20);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 64.35, -76.03 ),	( 0.89, 0.89 ), 16);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 48.44, -47.78 ),	( 0.9, 0.9 ),   10);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 29.75, -18.80 ),	( 0.92, 0.92 ), 5);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 14.73, -3.90 ),	( 0.94, 0.94 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 6.21, -1.65 ),	( 0.96, 0.96 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 1.83, -0.49 ),	( 0.98, 0.98 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON,	( 0.23, -0.06 ),	( 0.99, 0.99 ), 0);
		goto Anim_Ready;

	Anim_Deselect:
		#### # 0 { invoker.leftArmHideTimer = LEFTARMWAIT; } //trigger deselect of left arm
		HESW D 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 0.23, -0.06 ), ( 0.99, 0.99 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 1.83, -0.49 ), ( 0.98, 0.98 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 6.21, -1.65 ), ( 0.96, 0.96 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 14.73, -3.90 ), ( 0.94, 0.94 ), 0);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 29.75, -18.80 ), ( 0.92, 0.92 ), 5);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 48.44, -47.78 ), ( 0.9, 0.9 ),  10);
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 64.35, -76.03 ), ( 0.89, 0.89 ), 16);
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, ( 71.09, -88.74 ), ( 0.89, 0.89 ), 20);
		goto Anim_Ready;

	Anim_FirstSelect:
		HESW A 1 A_UpdateAnimationLayer(PSP_WEAPON, (50.321, -110.888), (1.0, 1.0), 30.065);	//	0
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (49.882, -109.959), (1.0, 1.0), 29.950);	//	1
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (48.612, -107.322), (1.0, 1.0), 29.611);	//	2
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (46.581, -103.206), (1.0, 1.0), 29.060);	//	3
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (43.861, -97.839), (1.0, 1.0), 28.309);	//	4
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (40.524, -91.447), (1.0, 1.0), 27.368);	//	5
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (36.639, -84.258), (1.0, 1.0), 26.249);	//	6
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (32.278, -76.501), (1.0, 1.0), 24.963);	//	7
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (27.512, -68.402), (1.0, 1.0), 23.522);	//	8
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (22.411, -60.190), (1.0, 1.0), 21.936);	//	9
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (17.048, -52.091), (1.0, 1.0), 20.217);	//	10
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (11.492, -44.333), (1.0, 1.0), 18.376);	//	11
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.816, -37.145), (1.0, 1.0), 16.426);	//	12
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.089, -30.753), (1.0, 1.0), 14.375);	//	13
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-5.616, -25.385), (1.0, 1.0), 12.237);	//	14
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-11.230, -21.270), (1.0, 1.0), 10.023);	//	15
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-16.681, -18.633), (1.0, 1.0), 7.743);	//	16
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-21.899, -17.704), (1.0, 1.0), 5.409);	//	17
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-26.793, -17.705), (1.0, 1.0), 3.055);	//	18
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-31.202, -17.708), (1.0, 1.0), 0.803);	//	19
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-34.945, -17.711), (1.0, 1.0), -1.200);	//	20
		// HESS frames show the sword being turned on:
		HESS A 1 A_UpdateAnimationLayer(PSP_WEAPON, (-37.842, -17.715), (1.0, 1.0), -2.812);	//	21
		HESS B 1 A_UpdateAnimationLayer(PSP_WEAPON, (-39.713, -17.717), (1.0, 1.0), -3.885);	//	22
		HESS C 1 A_UpdateAnimationLayer(PSP_WEAPON, (-40.376, -17.718), (1.0, 1.0), -4.275);	//	23
		HESS D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-37.185, -17.417), (1.003, 1.003), -3.398);	//	24
		HESS E 1 A_UpdateAnimationLayer(PSP_WEAPON, (-29.206, -16.599), (1.012, 1.012), -1.204);	//	25
		HESS F 1 A_UpdateAnimationLayer(PSP_WEAPON, (-18.834, -15.397), (1.025, 1.025), 1.646);	//	26
		HESS G 1 A_UpdateAnimationLayer(PSP_WEAPON, (-8.462, -13.941), (1.037, 1.037), 4.498);	//	27
		HESW B 1 A_UpdateAnimationLayer(PSP_WEAPON, (-0.484, -12.363), (1.046, 1.046), 6.691);	//	28
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.707, -10.795), (1.050, 1.050), 7.568);	//	29
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.706, -9.344), (1.049, 1.049), 7.567);	//	30
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.704, -8.027), (1.048, 1.048), 7.559);	//	31
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.696, -6.839), (1.046, 1.046), 7.538);	//	32
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.681, -5.771), (1.044, 1.044), 7.498);	//	33
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.657, -4.819), (1.041, 1.041), 7.430);	//	34
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.621, -3.975), (1.038, 1.038), 7.330);	//	35
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.571, -3.234), (1.034, 1.034), 7.190);	//	36
		#### C 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.505, -2.589), (1.030, 1.030), 7.003);	//	37
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.419, -2.033), (1.027, 1.027), 6.764);	//	38
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.312, -1.560), (1.023, 1.023), 6.465);	//	39
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.181, -1.165), (1.019, 1.019), 6.099);	//	40
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.025, -0.839), (1.015, 1.015), 5.661);	//	41
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.840, -0.578), (1.011, 1.011), 5.144);	//	42
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.624, -0.375), (1.008, 1.008), 4.540);	//	43
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.375, -0.222), (1.005, 1.005), 3.844);	//	44
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (1.090, -0.115), (1.003, 1.003), 3.048);	//	45
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.768, -0.046), (1.001, 1.001), 2.147);	//	46
		goto Anim_Ready;
	
	Anim_Fire:
		HESW D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-4.634, -0.037), (1.0, 1.0), -1.590);	//	49
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-15.068, -0.133), (1.0, 1.0), -3.654);	//	50
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-27.378, -0.256), (1.0, 1.0), -5.717);	//	51
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-37.641, -0.377), (1.0, 1.0), -7.303);	//	52
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-41.934, -0.465), (1.0, 1.0), -7.938);	//	53
		#### F 1 A_UpdateAnimationLayer(PSP_WEAPON, (-12.740, -0.565), (1.005, 1.005), -7.029);	//	54
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (51.486, -1.020), (1.018, 1.018), -4.683);	//	55
		#### G 1 A_UpdateAnimationLayer(PSP_WEAPON, (115.713, -2.245), (1.030, 1.030), -1.472);	//	56
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (144.908, -4.658), (1.036, 1.036), 2.030);	//	57
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (139.958, -15.227), (1.034, 1.034), 5.340);	//	58
		#### H 1 A_UpdateAnimationLayer(PSP_WEAPON, (126.891, -37.422), (1.029, 1.029), 8.309);	//	59
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (108.383, -66.415), (1.021, 1.021), 10.876);	//	60
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (87.105, -97.373), (1.014, 1.014), 12.979);	//	61
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (65.733, -125.466), (1.007, 1.007), 14.558);	//	62
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (46.941, -145.865), (1.002, 1.002), 15.550);	//	63
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (33.402, -153.738), (1.0, 1.0), 15.895);	//	64
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (25.005, -150.548), (1.0, 1.0), 15.780);	//	65
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (19.431, -141.712), (1.0, 1.0), 15.415);	//	66
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (16.043, -128.332), (1.0, 1.0), 14.772);	//	67
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (14.204, -111.509), (1.0, 1.0), 13.821);	//	68
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (13.275, -92.347), (1.0, 1.0), 12.533);	//	69
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (12.621, -71.946), (1.0, 1.0), 10.877);	//	70
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (11.603, -51.409), (1.0, 1.0), 8.826);	//	71
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (9.586, -31.838), (1.0, 1.0), 6.348);	//	72
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.930, -14.334), (1.0, 1.0), 3.416);	//	73
		goto Anim_Ready;
	
	Anim_Overhead:
		HESW C 1 A_UpdateAnimationLayer(PSP_WEAPON, (-8.448, 10.466), (1.026, 1.026), -3.828);	//	75
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-18.084, 17.972), (1.092, 1.092), -7.587);	//	76
		#### M 1 A_UpdateAnimationLayer(PSP_WEAPON, (-27.181, 23.831), (1.176, 1.176), -10.693);	//	77
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-34.013, 29.353), (1.257, 1.257), -12.565);	//	78
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-37.620, 35.309), (1.317, 1.317), -13.311);	//	79
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-38.949, 40.304), (1.353, 1.353), -13.586);	//	80
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-39.139, 42.399), (1.365, 1.365), -13.625);	//	81
		#### N 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.058, 26.558), (1.242, 1.242), -1.487);	//	82
		#### O 1 A_UpdateAnimationLayer(PSP_WEAPON, (81.073, -120.148), (1.098, 1.098), 17.267);	//	83
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (134.657, -211.993), (1.084, 1.084), 22.777);	//	84
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (125.992, -206.853), (1.084, 1.084), 22.777);	//	85
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (108.564, -194.288), (1.084, 1.084), 22.777);	//	86
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (92.973, -177.986), (1.082, 1.082), 22.329);	//	87
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (80.802, -159.269), (1.077, 1.077), 21.090);	//	88
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (71.383, -138.869), (1.070, 1.070), 19.218);	//	89
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (64.046, -117.514), (1.062, 1.062), 16.872);	//	90
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (58.122, -95.937), (1.052, 1.052), 14.209);	//	91
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (52.942, -74.866), (1.042, 1.042), 11.388);	//	92
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (47.836, -55.034), (1.031, 1.031), 8.568);	//	93
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (42.135, -37.169), (1.021, 1.021), 5.905);	//	94
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (35.170, -22.003), (1.013, 1.013), 3.559);	//	95
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (26.272, -10.265), (1.006, 1.006), 1.687);	//	96
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (14.772, -2.687), (1.001, 1.001), 0.448);	//	97
		goto Anim_Ready;
	
	Anim_Charge:
		HESW D 1 A_UpdateAnimationLayer(PSP_WEAPON, (-18.117, -7.316), (1.013, 1.013), 0.455);	//	99
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-37.268, -24.763), (1.045, 1.045), 1.542);	//	100
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-54.547, -45.588), (1.083, 1.083), 2.838);	//	101
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-67.046, -63.036), (1.115, 1.115), 3.925);	//	102
		#### I -1 A_UpdateAnimationLayer(PSP_WEAPON, (-71.858, -70.353), (1.129, 1.129), 4.381);	//	103
	Anim_ChargeEnd:
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-58.035, -56.928), (1.053, 1.053), 4.381);	//	104
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (-23.400, -27.954), (0.977, 0.977), 4.381);	//	105
		#### J 1 A_UpdateAnimationLayer(PSP_WEAPON, (18.275, 0.088), (1.057, 1.057), 2.807);	//	106
		#### K 1 A_UpdateAnimationLayer(PSP_WEAPON, (39.139, 12.580), (1.138, 1.138), 0.536);	//	107
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (38.548, 12.365), (1.137, 1.137), -0.597);	//	108
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (36.883, 11.766), (1.133, 1.133), -1.285);	//	109
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (34.302, 10.856), (1.127, 1.127), -1.638);	//	110
		#### I 1 A_UpdateAnimationLayer(PSP_WEAPON, (30.963, 9.705), (1.118, 1.118), -1.768);	//	111
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (27.024, 8.387), (1.106, 1.106), -1.786);	//	112
		#### B 1 A_UpdateAnimationLayer(PSP_WEAPON, (22.658, 6.971), (1.091, 1.091), -1.710);	//	113
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (18.093, 5.525), (1.074, 1.074), -1.507);	//	114
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (13.569, 4.117), (1.056, 1.056), -1.221);	//	115
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (9.326, 2.815), (1.039, 1.039), -0.893);	//	116
		#### D 1 A_UpdateAnimationLayer(PSP_WEAPON, (5.607, 1.684), (1.024, 1.024), -0.565);	//	117
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (2.653, 0.793), (1.011, 1.011), -0.279);	//	118
		#### # 1 A_UpdateAnimationLayer(PSP_WEAPON, (0.703, 0.210), (1.003, 1.003), -0.076);	//	119
		goto Anim_Ready;
	}
}