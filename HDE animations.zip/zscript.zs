version "4.12"

#include "HaloDoom_ZScript/baseweapon.zs"
#include "HaloDoom_ZScript/pistol.zs"
#include "HaloDoom_ZScript/lightrifle.zs"